<x-layout>
    <x-slot:heading>
        Contact Page
    </x-slot:heading>

    <h1>Hello from the Contact Page.</h1>
</x-layout>
