<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['active' => false]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['active' => false]); ?>
<?php foreach (array_filter((['active' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<a class="<?php echo e($active ? 'bg-gray-900 text-white': 'text-gray-300 hover:bg-gray-700 hover:text-white'); ?> rounded-md px-3 py-2 text-sm font-medium"
   aria-current="<?php echo e($active ? 'page': 'false'); ?>"
   <?php echo e($attributes); ?>

><?php echo e($slot); ?></a>
<?php /**PATH /Users/nooralamislammanik/Herd/class12/resources/views/components/nav-link.blade.php ENDPATH**/ ?>